create
  definer = root@localhost function setval(seq_name varchar(50), value int) returns int
BEGIN
UPDATE sequence
SET current_value = value 
WHERE name = seq_name; 
RETURN currval(seq_name); 
END;

