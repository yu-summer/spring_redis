create
  definer = root@localhost function currval(seq_name varchar(50)) returns int
BEGIN
DECLARE value INTEGER; 
SET value = 0;
SELECT 
    current_value
INTO value FROM
    sequence
WHERE
    name = seq_name; 
RETURN value; 
END;

