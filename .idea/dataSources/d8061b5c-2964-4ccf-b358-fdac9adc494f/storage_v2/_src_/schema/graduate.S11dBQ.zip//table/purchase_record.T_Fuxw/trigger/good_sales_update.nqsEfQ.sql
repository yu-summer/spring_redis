create definer = root@localhost trigger good_sales_update
  after UPDATE
  on purchase_record
  for each row
BEGIN
    IF new.is_pay = 1 THEN
      UPDATE goods_info SET sales = sales + new.quantity
      WHERE id = new.good_id;
    END IF;
end;

