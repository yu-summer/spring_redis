create definer = root@localhost trigger TR_DB_TA
  before DELETE
  on t_users
  for each row
BEGIN
DELETE from chat_record where username=old.username;
DELETE from commodity_evaluation WHERE username=old.username;
DELETE from purchase_record WHERE username=old.username;
END;

